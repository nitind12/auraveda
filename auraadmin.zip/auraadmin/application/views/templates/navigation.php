<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <?php $this->load->view('templates/header_navigate') ;?>
            <!-- /.navbar-top-links -->
            <?php $this->load->view('templates/side_navigation'); ?>
        </nav>